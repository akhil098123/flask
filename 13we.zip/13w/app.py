from flask import Flask, jsonify, render_template
import random

app = Flask(__name__)

# Sample match data
matches_data = [
    {
    "team1": "kerala blasters",
    "team1_logo": "https://ssl.gstatic.com/onebox/media/sports/logos/_5VS8XluJxBhUh29V2yB_Q_96x96.png",
    "team2": "Odisia",
    "team2_logo": "https://ssl.gstatic.com/onebox/media/sports/logos/8NSdffH3dYyTy5jLBAKDZA_96x96.png",
    "status": "completed",
    "score": "2-1",
    "match_time": "2025-01-20"
}, 
{
    "team1": "mumbia city",
    "team1_logo": "https://ssl.gstatic.com/onebox/media/sports/logos/pFOymUjummnYYqKp__o-LQ_96x96.png",
    "team2": "Odisia",
    "team2_logo": "https://ssl.gstatic.com/onebox/media/sports/logos/8NSdffH3dYyTy5jLBAKDZA_96x96.png",
    "status": "completed",
    "score": "2-1",
    "match_time": "2025-01-20"
}]

# Predefined live match data (the one you mentioned)
live = [
    {   
        "team1": "kozikode fc",
        "team2": "malapuram fc",
        "match-time": "Time: 23' + 2",
        "session" : "Live - first half" 
    }
]

# Sample rankings data
rankings_data = [
    {"team": "kerala blasters", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "ernakulam fc", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
    {"team": "kozhicode fc", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "malapuram fc", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team A", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team A", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
]

# Sample news images data
news_images_data = [
    {"image_url": "https://ssl.gstatic.com/onebox/media/sports/videos/vita/PZquM8u3aSrCLOmA_768x432.jpg", "alt": "Breaking News 1"},
    {"image_url": "https://ssl.gstatic.com/onebox/media/sports/videos/vita/g0ywi9ai48B26gIh_768x432.jpg", "alt": "Breaking News 2"},
    {"image_url": "https://ssl.gstatic.com/onebox/media/sports/videos/vita/BUXIU6YsYqME5bLZ_768x432.jpg", "alt": "Breaking News 3"},
]

@app.route('/get_matches/live')
def get_live_matches():
    # Return the predefined live match data as JSON
    return jsonify(live)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_matches/<status>')
def get_matches(status):
    # Filter matches based on the status (live, upcoming, recent, all)
    filtered_matches = [match for match in matches_data if match['status'] == status or status == 'all']
    return jsonify(filtered_matches)

@app.route('/get_rankings')
def get_rankings():
    # Render the rankings table as HTML
    return render_template('rankings_table.html', rankings=rankings_data)

@app.route('/get_news_images')
def get_news_images():
    return jsonify({"news_images": news_images_data})

if __name__ == '__main__':
    app.run(debug=True)
