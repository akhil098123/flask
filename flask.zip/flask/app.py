from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    # Dynamic data for the dashboard
    data = {
        "teams": [
            {"name": "Manchester United", "logo": "images/man_utd_logo.png", "country": "England"},
            {"name": "Liverpool", "logo": "images/liverpool_logo.png", "country": "England"},
            {"name": "Arsenal", "logo": "images/arsenal_logo.png", "country": "England"},
            {"name": "Real Madrid", "logo": "images/real_madrid_logo.png", "country": "Spain"},
            {"name": "Barcelona", "logo": "images/barcelona_logo.png", "country": "Spain"},
            {"name": "Bayern Munich", "logo": "images/bayern_logo.png", "country": "Germany"},
            {"name": "Paris Saint-Germain", "logo": "images/psg_logo.png", "country": "France"},
             {"name": "Manchester United", "logo": "images/man_utd_logo.png", "country": "England"},
            {"name": "Liverpool", "logo": "images/liverpool_logo.png", "country": "England"},
            {"name": "Arsenal", "logo": "images/arsenal_logo.png", "country": "England"},
            {"name": "Real Madrid", "logo": "images/real_madrid_logo.png", "country": "Spain"},
            {"name": "Barcelona", "logo": "images/barcelona_logo.png", "country": "Spain"},
            {"name": "Bayern Munich", "logo": "images/bayern_logo.png", "country": "Germany"},
            {"name": "Paris Saint-Germain", "logo": "images/psg_logo.png", "country": "France"},
        ],
        "matches": [
            {"teams": "Liverpool vs Man United", "score": "2-1", "status": "Live", "yc": 3},
            {"teams": "Chelsea vs Arsenal", "score": "1-1", "status": "Finished", "yc": 2},
        ],
        "rankings": [
            {"team": "Manchester United", "goals": 50, "rc": 1, "yc": 8, "points": 60},
            {"team": "Liverpool", "goals": 48, "rc": 2, "yc": 5, "points": 58},
            {"team": "Arsenal", "goals": 42, "rc": 0, "yc": 6, "points": 55},
        ],
    }
    return render_template('index.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
