from flask import Flask, jsonify, render_template
import random

app = Flask(__name__)

# Sample match data
matches_data = [
    {
        "team1": "Team C",
        "team2": "Team D",
        "status": "completed",
        "score": "2-1",
        "match_time": "2025-01-12T19:00:00Z"
    },
    {
        "team1": "Team E",
        "team2": "Team F",
        "status": "upcoming",
        "match_time": "2025-01-14T16:00:00Z"
    }
]

# Predefined live match data (the one you mentioned)
live = [
    {   
        "team1": "Team i",
        "team2": "Team D",
        "match-time": "Time: 45' + 2",
        "session" : "Live - Second Half" 
    }
]

# Sample rankings data
rankings_data = [
    {"team": "Team A", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team A", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team A", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team C", "mp": 10, "w": 4, "d": 4, "l": 2, "pts": 16},
    {"team": "Team A", "mp": 10, "w": 6, "d": 3, "l": 1, "pts": 21},
    {"team": "Team B", "mp": 10, "w": 5, "d": 2, "l": 3, "pts": 17},
]

# Sample news images data
news_images_data = [
    {"image_url": "https://via.placeholder.com/600x200", "alt": "Breaking News 1"},
    {"image_url": "https://via.placeholder.com/600x200", "alt": "Breaking News 2"},
    {"image_url": "https://via.placeholder.com/600x200", "alt": "Breaking News 3"},
]

@app.route('/get_matches/live')
def get_live_matches():
    # Return the predefined live match data as JSON
    return jsonify(live)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_matches/<status>')
def get_matches(status):
    # Filter matches based on the status (live, upcoming, recent, all)
    filtered_matches = [match for match in matches_data if match['status'] == status or status == 'all']
    return jsonify(filtered_matches)

@app.route('/get_rankings')
def get_rankings():
    # Render the rankings table as HTML
    return render_template('rankings_table.html', rankings=rankings_data)

@app.route('/get_news_images')
def get_news_images():
    return jsonify({"news_images": news_images_data})

if __name__ == '__main__':
    app.run(debug=True)
